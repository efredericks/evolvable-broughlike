// helper to get a random item from an array
function getRandomArray(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

// fisher-yates shuffle
function shuffle(arr) {
    let temp, r;
    for (let i = 1; i < arr.length; i++) {
        r = randomRange(0, i);
        temp = arr[i];
        arr[i] = arr[r];
        arr[r] = temp;
    }
    return arr;
}


// random integer in range
function randomRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// try function to place things in open spaces
function tryTo(desc, cb, _timeout = 1000) {
    for (let timeout = _timeout; timeout >= 0; timeout--) {
        if (cb()) return;
    }
    throw `Timeout trying to: ${desc}`;
}

// text padding
function rightPad(textArray) {
    let finalText = "";
    textArray.forEach(text => {
        text += "";
        for (let i = text.length; i < 10; i++) {
            text += " ";
        }
        finalText += text;
    });
    return finalText;
}

// local to world
function worldToChunk(worldCol, worldRow) {
    const cc = Math.floor(worldCol / numTiles);
    const cr = Math.floor(worldRow / numTiles);

    // mod for negative coords
    const lc = ((worldCol % numTiles) + numTiles) % numTiles;
    const lr = ((worldRow % numTiles) + numTiles) % numTiles;

    return { chunk_col: cc, chunk_row: cr, local_col: lc, local_row: lr };
}
// world to local
function chunkToWorld(chunk_col, chunk_row, local_col, local_row) {
    const wc = chunk_col * numTiles + local_col;
    const wr = chunk_row * numTiles + local_row;
    return { world_col: wc, world_row: wr };
}

// transform mouse coords to allow mouseover of entities
// based on https://jsfiddle.net/mattdeeds/yqLvza57/37/
function getCanvasCoords(ctx, screenX, screenY) {
    let matrix = ctx.getTransform();
    var imatrix = matrix.invertSelf();
    let x = screenX * imatrix.a + screenY * imatrix.c + imatrix.e;
    let y = screenX * imatrix.b + screenY * imatrix.d + imatrix.f;
    return [x, y];
}
function getMousePos(canvas, evt) {
    var rect = canvas.getBoundingClientRect(), // abs. size of element
        scaleX = canvas.width / rect.width,    // relationship bitmap vs. element for X
        scaleY = canvas.height / rect.height;  // relationship bitmap vs. element for Y

    return [
        (evt.clientX - rect.left) * scaleX,
        (evt.clientY - rect.top) * scaleY];
}
function handleMouse(e) {
    [mouseX, mouseY] = getMousePos(game.canvas, e);
    mouseTimer = mouseTimeout;
}

// map number range
// https://stackoverflow.com/questions/10756313/javascript-jquery-map-a-range-of-numbers-to-another-range-of-numbers
function scaleValue(number, inMin, inMax, outMin, outMax) {
    return (number - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}
